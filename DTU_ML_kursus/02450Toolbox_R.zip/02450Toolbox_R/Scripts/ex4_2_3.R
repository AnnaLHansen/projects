# exercise 4.2.3


boxplot(X, main="Boxplots of attribute values")
